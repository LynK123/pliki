import java.util.Scanner;

public class NajwiekszaZTrzech {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Podaj pierwszą liczbę: ");
        int a = sc.nextInt();

        System.out.print("Podaj drugą liczbę: ");
        int b = sc.nextInt();

        System.out.print("Podaj trzecią liczbę: ");
        int c = sc.nextInt();

        int max = a;

        if (b > max) {
            max = b;
        }

        if (c > max) {
            max = c;
        }

        System.out.println("Największa liczba: " + max);
    }
}
