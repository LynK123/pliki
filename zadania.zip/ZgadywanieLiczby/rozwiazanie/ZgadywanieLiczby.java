import java.util.Scanner;
import java.util.Random;

public class ZgadywanieLiczby{
  public static void main(String[] args) {
    Random rand = new Random();
    Scanner sc = new Scanner(System.in);
    int numberToGuess = rand.nextInt(100) + 1;
    boolean guessing = true;
    
    while(guessing){
      System.out.println("Zgadnij liczbę od 1 do 100");
      int guessedNumber = sc.nextInt();

      if(numberToGuess == guessedNumber){
        System.out.println("Zgadłeś liczbę to było: " + numberToGuess);
        System.out.println("Chcesz zagrac jeszcze raz? (napisz tak lub nie)");
        String nextGame = sc.next();
        if(nextGame.equals("tak")){
          numberToGuess = rand.nextInt(100) + 1;
        }else if(nextGame.equals("nie")){
          guessing = false;
        }
      }else if(numberToGuess > guessedNumber){
        System.out.println("Liczba jest zbyt mała!");
      }else if(numberToGuess < guessedNumber){
        System.out.println("Liczba jest zbyt duża!");
      }
    }
  }
}

