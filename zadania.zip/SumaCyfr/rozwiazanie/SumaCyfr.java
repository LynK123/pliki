import java.util.Scanner;
import java.lang.Math;

public class SumaCyfr{
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Podaj liczbę: ");
    int num = sc.nextInt();
    num = Math.abs(num);
    int suma = 0;

    while(num > 0){
      suma += num % 10;
      num /= 10;
    }

    System.out.println("Suma cyfr wynosi: " + suma);
  }
}
