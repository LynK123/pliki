import java.util.Scanner;

public class FizzBuzz {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj maksymalna liczbe: ");
        int maxNum = scanner.nextInt();
        String message = "";
        for(int i = 1; i <= maxNum; i++) {
            message = i + "";
            if (i % 3 == 0) {
                message += " Fizz";
            }
            if (i % 5 == 0) {
                message += " Buzz";
            }
            if (message != ""){
                System.out.println(message);
            }
        }
    }
}
