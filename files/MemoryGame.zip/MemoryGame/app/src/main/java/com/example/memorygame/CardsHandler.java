package com.example.memorygame;

import static java.util.Collections.shuffle;

import java.util.ArrayList;
import java.util.Collections;

public class CardsHandler {
    ArrayList<Card> cards;
    int duplicates;

    public CardsHandler(ArrayList<Card> cards, int duplicates) {
        this.cards = cards;
        this.duplicates = duplicates;
    }

    public ArrayList<Card> randomizeCards() {
        ArrayList<Card> generatedCards = new ArrayList<Card>();
        for (Card card : cards) {
            for (int i = 0; i < duplicates; i++) {
                generatedCards.add(card);
            }
        }
    }
}
