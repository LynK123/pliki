package com.example.memorygame;

public class Card {
    protected int value;
    public boolean isRevealed;
    public boolean isMatched;

    public Card(int value, boolean isRevealed, boolean isMatched) {
        this.value = value;
        this.isRevealed = isRevealed;
        this.isMatched = isMatched;
    }

    public int getValue() {
        return value;
    }
}
